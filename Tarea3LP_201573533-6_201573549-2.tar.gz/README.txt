Integrantes:
Juan Pablo Jorquera Zapata       201573533-6
Cristian Andres Navarrete Galvez 201573549-2

La interfaz gráfica fue hecha usando javax Swing.

Instrucciones:

Para compilar:
make

Para correr:
make run

- Limpieza:
make clean

Atención: El makefile requiere de ant tanto para limpiar como para compilar.